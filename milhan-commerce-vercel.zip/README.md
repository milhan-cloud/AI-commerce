# Milhan Commerce (Vercel)
Situs statis satu file (`index.html`), tanpa build step.

## Deploy ke Vercel
1. Buat repo GitHub baru, upload isi folder ini.
2. Di vercel.com: Add New > Project, pilih repo, Framework Preset: Other, Build Command kosong, Output Directory kosong.
3. Deploy.

Atau lewat CLI: `npx vercel --prod` dari dalam folder ini.

## Database
Project Supabase: ndshakkunvbcfqagmwak (nama: commerce).
Tabel dan RLS sudah diterapkan. Publishable key aman ditaruh di frontend; data dilindungi RLS.
